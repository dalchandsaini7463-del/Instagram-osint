import re

USERNAME_RE = re.compile(r"^[A-Za-z0-9._]{1,30}$")

def validate_username(value: str):
    value = value.strip().lstrip("@")
    return value if USERNAME_RE.fullmatch(value) else None
