import csv
import html
import json
import logging
import hashlib
from pathlib import Path
from config import REPORT_DIR, LOG_DIR

def _flat_rows(result):
    rows = []
    for k, v in result["public_information"].items():
        rows.append({
            "field": k,
            "value": v,
            "source": result.get("source", "NOT AVAILABLE"),
            "collection_time": result.get("collection_time_utc", "NOT AVAILABLE"),
            "confidence": result.get("confidence", {}).get(k, "not assessed"),
            "notes": "; ".join(result.get("notes", []))
        })
    return rows

def write_reports(result, mode):
    REPORT_DIR.mkdir(exist_ok=True)
    LOG_DIR.mkdir(exist_ok=True)
    safe_target = "".join(c if c.isalnum() or c in "._-" else "_" for c in result["target"])
    stem = REPORT_DIR / f"{safe_target}_{mode[2:].replace('-', '_')}"

    json_path = stem.with_suffix(".json")
    csv_path = stem.with_suffix(".csv")
    html_path = stem.with_suffix(".html")

    if mode == "./govt-work":
        canonical = json.dumps(result, sort_keys=True, ensure_ascii=False).encode()
        result["chain_of_custody"] = {
            "record_sha256": hashlib.sha256(canonical).hexdigest(),
            "created_utc": result["collection_finished_utc"],
            "integrity_note": "Hash covers the collected JSON record before report serialization."
        }

    json_path.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")

    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["field","value","source","collection_time","confidence","notes"])
        writer.writeheader()
        writer.writerows(_flat_rows(result))

    rows = _flat_rows(result)
    trs = "".join(
        "<tr>" + "".join(f"<td>{html.escape(str(r[c]))}</td>" for c in
        ["field","value","source","collection_time","confidence","notes"]) + "</tr>"
        for r in rows
    )
    html_path.write_text(
        "<!doctype html><html><head><meta charset='utf-8'><title>OSINT Report</title>"
        "<style>body{font-family:system-ui;margin:2rem}table{border-collapse:collapse;width:100%}"
        "td,th{border:1px solid #ccc;padding:.5rem;text-align:left}</style></head><body>"
        f"<h1>Instagram Public-OSINT Report</h1><p>Mode: {html.escape(mode)}</p>"
        f"<p>Status: {html.escape(result['status'])}</p>"
        "<table><tr><th>Field</th><th>Value</th><th>Source</th><th>Collection Time</th>"
        "<th>Confidence</th><th>Notes</th></tr>" + trs + "</table></body></html>",
        encoding="utf-8"
    )

    logging.getLogger("insta_osint").info("Reports written for %s", result["target"])
    return [str(json_path), str(csv_path), str(html_path)]
