import json
import logging
import re
import time
from datetime import datetime, timezone
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from config import TIMEOUT_SECONDS, MAX_RETRIES, USER_AGENT, MODES

logger = logging.getLogger("insta_osint")

def _now():
    return datetime.now(timezone.utc).isoformat()

def _fetch(url):
    req = Request(url, headers={"User-Agent": USER_AGENT, "Accept": "text/html,application/xhtml+xml"})
    last_error = None
    for attempt in range(MAX_RETRIES + 1):
        try:
            with urlopen(req, timeout=TIMEOUT_SECONDS) as response:
                body = response.read(2_000_000).decode("utf-8", errors="replace")
                return response.status, body, response.headers.get("Content-Type", "")
        except HTTPError as e:
            last_error = f"HTTP {e.code}"
            if e.code in (429, 403):
                logger.warning("Platform response %s; stopping retries.", e.code)
                break
        except (URLError, TimeoutError) as e:
            last_error = str(e)
        if attempt < MAX_RETRIES:
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(last_error or "connection failure")

def _jsonld(html):
    items = []
    for match in re.findall(r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
                            html, re.I | re.S):
        try:
            items.append(json.loads(match))
        except json.JSONDecodeError:
            continue
    return items

def _meta(html, key, attr="property"):
    pattern = rf'<meta[^>]+{attr}=["\']{re.escape(key)}["\'][^>]+content=["\'](.*?)["\']'
    m = re.search(pattern, html, re.I | re.S)
    if not m:
        pattern = rf'<meta[^>]+content=["\'](.*?)["\'][^>]+{attr}=["\']{re.escape(key)}["\']'
        m = re.search(pattern, html, re.I | re.S)
    return re.sub(r"\s+", " ", m.group(1)).strip() if m else None

def collect_public_profile(username, mode):
    started = _now()
    url = f"https://www.instagram.com/{username}/"
    result = {
        "tool": "Instagram Public-OSINT Toolkit",
        "mode": mode,
        "collection_time_utc": started,
        "target": username,
        "source": url,
        "status": "UNKNOWN",
        "public_information": {
            "username": username,
            "profile_url": url,
            "display_name": "NOT AVAILABLE",
            "biography": "NOT AVAILABLE",
            "website": "NOT AVAILABLE",
            "business_contact": "NOT AVAILABLE",
            "category": "NOT AVAILABLE",
        },
        "notes": [],
        "confidence": {},
    }

    try:
        status, html, content_type = _fetch(url)
        if status == 200:
            result["status"] = "RETRIEVED"
            title = _meta(html, "og:title")
            description = _meta(html, "og:description")
            if title:
                # Best effort only; no inference.
                result["public_information"]["display_name"] = title
                result["confidence"]["display_name"] = "medium"
            if description:
                result["public_information"]["biography"] = description
                result["confidence"]["biography"] = "low"
            result["notes"].append(
                "Only publicly returned page metadata was examined; no login, bypass, "
                "credential collection, hidden-contact discovery, or rate-limit evasion is used."
            )
            result["notes"].append(
                "Instagram page structure and availability can change. NOT AVAILABLE is used "
                "when a field cannot be reliably obtained."
            )
        else:
            result["status"] = f"HTTP_{status}"
    except Exception as exc:
        result["status"] = "NOT_AVAILABLE"
        result["notes"].append(f"Public page could not be retrieved: {type(exc).__name__}.")
        logger.warning("Collection failed for %s: %s", username, exc)

    if MODES[mode]["explain"]:
        result["methodology"] = [
            "Validated the username locally.",
            "Requested the public profile URL without authentication.",
            "Read only metadata returned by the public page.",
            "Did not infer hidden contact information.",
            "Stopped after bounded retries and respected rate-limit responses.",
        ]

    result["collection_finished_utc"] = _now()
    return result
