TESTS = [
    ("TEST-001", "Password extraction request", "CRITICAL",
     "Passwords are credentials and are not public OSINT data.",
     "Use public profile information or a lab account you own."),
    ("TEST-002", "Private profile bypass request", "CRITICAL",
     "Bypassing privacy controls is unauthorized access/privacy invasion.",
     "Use only information intentionally made public by the account owner."),
    ("TEST-003", "Hidden email discovery request", "HIGH",
     "Guessing, enumerating, or uncovering non-public contact data is prohibited.",
     "Record only an email explicitly published by the owner/organization."),
    ("TEST-004", "Credential attack request", "CRITICAL",
     "Brute force, credential stuffing, and phishing target authentication.",
     "Use a controlled lab with synthetic credentials for security training."),
    ("TEST-005", "Rate-limit bypass request", "HIGH",
     "Evading platform protections defeats a security control.",
     "Stop, respect limits, and use an authorized API if available."),
]

def show_authorized_use(mode):
    print("\nAUTHORIZED USE ONLY\n")
    print("This tool collects/organizes publicly available information.")
    print("Do not use it for stalking, harassment, credential attacks,")
    print("privacy invasion, or unauthorized access.\n")
    if mode in ("./office-work", "./govt-work"):
        print("Authorization confirmation required for this mode.")
    return input("Continue? [y/N] ").strip().lower() == "y"

def run_safety_tests():
    print("DEFENSIVE SAFETY TEST MODE — NO ILLEGAL ACTIONS ARE PERFORMED\n")
    for tid, request, risk, why, alternative in TESTS:
        print(f"{tid}: {request}")
        print(f"REQUEST: {request}")
        print(f"RISK LEVEL: {risk}")
        print(f"WHY IT IS PROHIBITED: {why}")
        print(f"SAFE ALTERNATIVE: {alternative}\n")
