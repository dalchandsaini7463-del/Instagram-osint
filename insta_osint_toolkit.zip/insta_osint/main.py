import argparse
import logging
from config import LOG_DIR
from modules.safety import show_authorized_use, run_safety_tests
from modules.validation import validate_username
from modules.profile import collect_public_profile
from modules.reports import write_reports

def main():
    LOG_DIR.mkdir(exist_ok=True)
    logging.basicConfig(filename=LOG_DIR / 'activity.log', level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    parser = argparse.ArgumentParser(description="Instagram Public-OSINT Toolkit")
    parser.add_argument("mode", nargs="?", choices=["./education", "./office-work", "./govt-work"])
    parser.add_argument("username", nargs="?")
    parser.add_argument("--safety-test", action="store_true")
    args = parser.parse_args()

    if args.safety_test:
        if args.mode not in (None, "./education"):
            parser.error("--safety-test is available only with ./education")
        run_safety_tests()
        return

    if not args.mode or not args.username:
        parser.error("Usage: python main.py ./education USERNAME")

    if not show_authorized_use(args.mode):
        print("Cancelled.")
        return

    username = validate_username(args.username)
    if not username:
        print("Invalid username.")
        return

    result = collect_public_profile(username, args.mode)
    paths = write_reports(result, args.mode)
    print("\nInvestigation complete.")
    for p in paths:
        print(f"Report: {p}")

if __name__ == "__main__":
    main()
