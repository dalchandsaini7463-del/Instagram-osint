from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parent
REPORT_DIR = BASE_DIR / "reports"
LOG_DIR = BASE_DIR / "logs"

TIMEOUT_SECONDS = int(os.getenv("INSTA_OSINT_TIMEOUT", "10"))
MAX_RETRIES = int(os.getenv("INSTA_OSINT_MAX_RETRIES", "2"))
USER_AGENT = os.getenv(
    "INSTA_OSINT_USER_AGENT",
    "InstaPublicOSINT-Education/1.0 (+authorized-public-information-tool)"
)

MODES = {
    "./education": {"profile": "educational", "explain": True, "audit": False},
    "./office-work": {"profile": "corporate", "explain": False, "audit": True},
    "./govt-work": {"profile": "government-authorized", "explain": False, "audit": True},
}
