import unittest
from modules.validation import validate_username
from modules.safety import TESTS

class SafetyTests(unittest.TestCase):
    def test_username_validation(self):
        self.assertEqual(validate_username("example.user"), "example.user")
        self.assertEqual(validate_username("@example_user"), "example_user")
        self.assertIsNone(validate_username("bad username"))
        self.assertIsNone(validate_username("../secret"))

    def test_prohibited_cases_are_present(self):
        ids = {t[0] for t in TESTS}
        self.assertEqual(ids, {"TEST-001","TEST-002","TEST-003","TEST-004","TEST-005"})

    def test_no_credentials_in_safety_cases(self):
        text = repr(TESTS).lower()
        self.assertNotIn("password=", text)
        self.assertNotIn("cookie=", text)
        self.assertNotIn("sessionid=", text)

if __name__ == "__main__":
    unittest.main()
