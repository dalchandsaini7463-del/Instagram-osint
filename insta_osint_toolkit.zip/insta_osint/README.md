# Instagram Public-OSINT Toolkit

Python-only, defensive OSINT toolkit for authorized public-information research.

## Scope

The toolkit is intentionally limited to information returned by a public profile page
without authentication or privacy bypass. It does not implement password collection,
phishing, credential attacks, private-profile bypass, hidden-contact discovery,
IP grabbing, tracking, doxxing, CAPTCHA/rate-limit bypass, exploitation, malware,
or stealth persistence.

Instagram availability and page structure can change. The tool therefore uses
`NOT AVAILABLE` rather than guessing.

## Modes

- `./education` — educational methodology notes and local/lab use.
- `./office-work` — requires an authorization confirmation and produces audit-oriented reports.
- `./govt-work` — requires authorization confirmation and adds chain-of-custody metadata.
  This is NOT an official government tool.

## Installation

Python 3.10+ is recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
python main.py ./education example
```

No third-party Python packages are required.

## CLI

```bash
python main.py ./education USERNAME
python main.py ./office-work USERNAME
python main.py ./govt-work USERNAME
python main.py ./education --safety-test
python -m unittest discover -s tests
```

## Reports

Reports are written to `reports/` as JSON, CSV and HTML.

Each record contains collected public information, source, collection time,
confidence where assessed, and notes. Missing values are `NOT AVAILABLE`.

## Operational safeguards

- Username validation
- Bounded retries
- Timeout handling
- Stops on HTTP 403/429
- No authentication
- No credential/token/cookie logging
- No hidden email/phone inference
- No unlimited retries or rate-limit evasion

Use only where you have appropriate authorization and where collection complies
with Instagram's terms, applicable laws, and organizational policy.
